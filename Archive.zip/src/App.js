import './App.css';
import FormComp from './components/form';

function App() {
  return (
    <div className="form-container">
      <FormComp />
    </div>
  );
}

export default App;
